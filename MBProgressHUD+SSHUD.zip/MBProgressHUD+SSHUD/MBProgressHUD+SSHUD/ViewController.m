//
//  ViewController.m
//  MBProgressHUD+SSHUD
//
//  Created by 刘秋林 on 2017/4/18.
//  Copyright © 2017年 刘秋林. All rights reserved.
//

#import "ViewController.h"

#import "MBProgressHUD+SSHUD.h"

@interface ViewController ()

@property (nonatomic, assign) BOOL autoHidden;

@end

@implementation ViewController

- (IBAction)showSuccess:(UIButton *)sender {
    [MBProgressHUD showSuccess:@"Success！"];
}

- (IBAction)showFailure:(UIButton *)sender {
    [MBProgressHUD showError:@"网络错误！"];
}

- (IBAction)showInfo:(UIButton *)sender {
    [MBProgressHUD showInfo:@"暂无数据！"];
}

- (IBAction)showLoading:(UIButton *)sender {
    [MBProgressHUD showLoading:@"加载中..."];
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(3.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [MBProgressHUD dismiss];
    });
}

@end
