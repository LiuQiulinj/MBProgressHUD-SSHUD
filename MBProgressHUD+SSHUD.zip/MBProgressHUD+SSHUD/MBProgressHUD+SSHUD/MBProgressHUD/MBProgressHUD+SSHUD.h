//
//  MBProgressHUD+SSHUD.h
//  HudDemo
//
//  Created by 刘秋林 on 2017/4/18.
//  Copyright © 2017年 Matej Bukovinski. All rights reserved.
//

#import "MBProgressHUD.h"

@interface MBProgressHUD (SSHUD)

+ (void)showLoading:(NSString *)loadingMsg;

+ (void)showSuccess:(NSString *)successMsg;

+ (void)showError:(NSString *)errorMsg;

+ (void)showInfo:(NSString *)msg;

+ (void)dismiss;

@end
