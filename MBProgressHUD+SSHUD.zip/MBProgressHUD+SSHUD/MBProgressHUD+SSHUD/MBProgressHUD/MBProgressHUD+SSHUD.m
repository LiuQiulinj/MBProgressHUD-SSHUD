//
//  MBProgressHUD+SSHUD.m
//  HudDemo
//
//  Created by 刘秋林 on 2017/4/18.
//  Copyright © 2017年 Matej Bukovinski. All rights reserved.
//

#import "MBProgressHUD+SSHUD.h"

#import "AppDelegate.h"

#define kDelay 3.0

#define kKeyWindow [UIApplication sharedApplication].keyWindow

@implementation MBProgressHUD (SSHUD)

+ (void)showLoading:(NSString *)loadingMsg {
    dispatch_async(dispatch_get_main_queue(), ^{
        MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:kKeyWindow animated:YES];
        if (loadingMsg && loadingMsg.length) {
            hud.label.text = loadingMsg;
        }
    });
}

+ (void)showSuccess:(NSString *)successMsg {
    [self showHUD:@"success" msg:successMsg];
}

+ (void)showError:(NSString *)errorMsg {
    [self showHUD:@"error" msg:errorMsg];
}

+ (void)showInfo:(NSString *)msg {
    [self showHUD:@"info" msg:msg];
}

+ (void)showHUD:(NSString *)imageName msg:(NSString *)msg {
    dispatch_async(dispatch_get_main_queue(), ^{
        MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:kKeyWindow animated:YES];
        hud.mode = MBProgressHUDModeCustomView;
        if (msg && msg.length) {
            hud.label.text = msg;
        }
        hud.customView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:imageName]];
    });
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(kDelay * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        [self hideHUDForView:kKeyWindow animated:YES];
    });
}

+ (void)dismiss {
    dispatch_async(dispatch_get_main_queue(), ^{
        [self hideHUDForView:kKeyWindow animated:YES];
    });
}

@end
